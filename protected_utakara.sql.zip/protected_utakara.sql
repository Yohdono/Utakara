-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 14, 2010 at 09:03 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `protected_utakara`
--

-- --------------------------------------------------------

--
-- Table structure for table `artists`
--

CREATE TABLE IF NOT EXISTS `artists` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `artists`
--


-- --------------------------------------------------------

--
-- Table structure for table `karaokealerts`
--

CREATE TABLE IF NOT EXISTS `karaokealerts` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `kara` mediumint(8) unsigned NOT NULL,
  `typeid` mediumint(8) unsigned NOT NULL,
  `date` datetime DEFAULT NULL,
  `status` binary(1) DEFAULT NULL,
  `pos` mediumint(8) unsigned NOT NULL,
  `sender` varchar(255) NOT NULL,
  `comment` text,
  PRIMARY KEY (`id`),
  KEY `kara` (`kara`),
  KEY `typeid` (`typeid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `karaokealerts`
--


-- --------------------------------------------------------

--
-- Table structure for table `karaokealertstype`
--

CREATE TABLE IF NOT EXISTS `karaokealertstype` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `karaokealertstype`
--


-- --------------------------------------------------------

--
-- Table structure for table `karaokeorigin`
--

CREATE TABLE IF NOT EXISTS `karaokeorigin` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `typeid` mediumint(8) unsigned NOT NULL,
  `position` mediumint(8) unsigned NOT NULL,
  `flag` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `typeid` (`typeid`),
  KEY `position` (`position`),
  KEY `flag` (`flag`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `karaokeorigin`
--


-- --------------------------------------------------------

--
-- Table structure for table `karaokeoriginflag`
--

CREATE TABLE IF NOT EXISTS `karaokeoriginflag` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `karaokeoriginflag`
--


-- --------------------------------------------------------

--
-- Table structure for table `karaokeoriginposition`
--

CREATE TABLE IF NOT EXISTS `karaokeoriginposition` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `karaokeoriginposition`
--


-- --------------------------------------------------------

--
-- Table structure for table `karaokeorigintype`
--

CREATE TABLE IF NOT EXISTS `karaokeorigintype` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `karaokeorigintype`
--


-- --------------------------------------------------------

--
-- Table structure for table `karaokestats`
--

CREATE TABLE IF NOT EXISTS `karaokestats` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `grade` double NOT NULL,
  `nbgrader` mediumint(8) unsigned NOT NULL,
  `play` mediumint(8) unsigned NOT NULL,
  `last` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `karaokestats`
--


-- --------------------------------------------------------

--
-- Table structure for table `karaoketags`
--

CREATE TABLE IF NOT EXISTS `karaoketags` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `karaoketags`
--


-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE IF NOT EXISTS `languages` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `languages`
--


-- --------------------------------------------------------

--
-- Table structure for table `playablekaraoke`
--

CREATE TABLE IF NOT EXISTS `playablekaraoke` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `filename` varchar(128) NOT NULL,
  `stats` mediumint(8) unsigned NOT NULL,
  `timerid` mediumint(8) unsigned NOT NULL,
  `karaid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `stats` (`stats`),
  KEY `timerid` (`timerid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `playablekaraoke`
--


-- --------------------------------------------------------

--
-- Table structure for table `playablekaraokeartist`
--

CREATE TABLE IF NOT EXISTS `playablekaraokeartist` (
  `artid` mediumint(8) unsigned NOT NULL,
  `karaid` mediumint(8) unsigned NOT NULL,
  KEY `karaid` (`karaid`),
  KEY `artid` (`artid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `playablekaraokeartist`
--


-- --------------------------------------------------------

--
-- Table structure for table `playablekaraokelanguage`
--

CREATE TABLE IF NOT EXISTS `playablekaraokelanguage` (
  `langid` mediumint(8) unsigned NOT NULL,
  `karaid` mediumint(8) unsigned NOT NULL,
  KEY `karaid` (`karaid`),
  KEY `langid` (`langid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `playablekaraokelanguage`
--


-- --------------------------------------------------------

--
-- Table structure for table `playablekaraoketag`
--

CREATE TABLE IF NOT EXISTS `playablekaraoketag` (
  `karaid` mediumint(8) unsigned NOT NULL,
  `tagid` mediumint(8) unsigned NOT NULL,
  `name` varchar(64) NOT NULL,
  KEY `karaid` (`karaid`),
  KEY `tagid` (`tagid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `playablekaraoketag`
--


-- --------------------------------------------------------

--
-- Table structure for table `playablekaraoketimer`
--

CREATE TABLE IF NOT EXISTS `playablekaraoketimer` (
  `timerid` mediumint(8) unsigned NOT NULL,
  `karaid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`timerid`,`karaid`),
  KEY `karaid` (`karaid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `playablekaraoketimer`
--


-- --------------------------------------------------------

--
-- Table structure for table `timers`
--

CREATE TABLE IF NOT EXISTS `timers` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `user_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `timers`
--

